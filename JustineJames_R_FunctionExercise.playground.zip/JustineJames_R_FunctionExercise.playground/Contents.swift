//first try
func Addition () {
    let a = 9
    let b = 100
    let c = a + b
    print(c)
}
Addition()



//second try
func addtwo (a: Int, b: Int) -> Int {
    var sum = 0
    sum = a + b
    
    return sum
}
var Sumtotal = addtwo(a: 4, b: 10)




//third try
var a = 10
var b = 40

func plus(min: Int, max: Int) -> Int {
    let a = 10
    let b = 40
    return a + b
}
print(plus(min: a, max: b))
