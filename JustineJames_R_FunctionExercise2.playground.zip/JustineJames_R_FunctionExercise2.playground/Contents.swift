

let mult = {
    (num1: Int, num2: Int) -> Int in
    return num1 * num2
}
let numbers = mult(10,5)
print(numbers)


