//numbers
let Button1 = 1
let Button2 = 2
let Button3 = 3
let Button4 = 4
let Button5 = 5
let Button6 = 6
let Button7 = 7
let Button8 = 8
let Button9 = 9

//operations
var Addition = "\(Button1) + \(Button2)"
var Subtraction = "\(Button3) - \(Button4)"
var Divide = "\(Button5) / \(Button6)"
var Multiplication = "\(Button7) * \(Button8)"

//Answers
print(Button7+Button3)
print(Button5-Button4)
print(Button8/Button2)
print(Button9*Button6)


